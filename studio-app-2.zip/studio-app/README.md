# Studio — beverage AI website builder (full prototype)

A real, running Next.js app implementing the complete flow: pick a
category (or a few) → sign in → agents generate the site → edit
conversationally → connect your domain → pay for more.

## What's actually working here

**Core generation pipeline**
- Category picker with primary/secondary blending (`components/CategoryPicker.tsx`, `lib/blend.ts`, `lib/designSystems.ts`)
- Moodboard upload with client-side dominant-color extraction and a
  guardrail against dragging a category off-brand (`components/MoodboardUpload.tsx`, `lib/moodboard.ts`)
- AI copy generation via Claude, including category-specific signature
  sections (ingredient breakdown, tasting notes, social proof, lab
  results, origin story) — compliance/disclaimer text is retrieved from
  `lib/compliance.ts`, never generated (`lib/generateSite.ts`)
- Logo generation composed from the same design-system tokens as the
  site — never a freeform image model (`lib/generateLogo.ts`)
- Real-time generation progress: a `GenerationJob` row is updated at
  each pipeline stage and polled by `/building`, instead of a
  fixed-time fake checklist (`app/api/generate/route.ts`, `app/api/generate/status/route.ts`)
- Site rendering themed per resolved design system, including the
  signature section (`components/SitePreview.tsx`)

**Accounts, access, and money**
- Real Google auth via NextAuth, database-backed sessions (`lib/auth.ts`)
- Real Vercel Domains API integration — attach domain, check DNS
  config, handle the three real outcomes (verified / DNS pending /
  needs ownership-proof TXT record) (`lib/vercelDomains.ts`, `app/api/domain/route.ts`)
- **Multi-tenant domain routing** (`middleware.ts`, `app/_sites/[[...slug]]/page.tsx`)
  — this is the actual last mile between "domain verified" and a
  customer's site loading on their own domain. `middleware.ts` inspects
  the incoming `Host` header on every request; anything that isn't your
  platform's own domain gets rewritten to `/_sites/...`, a plain public
  page (no owner chrome, no edit bar) that looks up the matching `Site`
  by domain and renders it. The database lookup deliberately happens
  there, not in middleware — middleware runs on the Edge runtime, where
  Prisma's Node.js client doesn't work reliably.
- Real Razorpay subscriptions for the three plan tiers, webhook-driven
  activation (not just the client-side checkout callback), and
  plan-based site limits enforced before generation, with a 1-site free
  trial (`lib/plans.ts`, `lib/razorpay.ts`, `lib/planLimits.ts`, `app/billing/*`, `app/api/billing/*`)
- Pro-tier team seats: invite an existing user to your team; sites can
  belong to a team, not just a single owner (`lib/access.ts`, `app/api/team/invite/route.ts`)

**Editing and management**
- Conversational editing agent: an instruction maps to a targeted patch
  on just the block(s) it touches, never a full rewrite; compliance
  text is structurally excluded from what the LLM can edit
  (`lib/editSite.ts`, `app/api/edit/*`, `components/EditBar.tsx`)
- Undo, via a `SiteRevision` snapshot taken before every edit
- Sites dashboard listing all of a user's sites, their live/domain
  status, and whether a custom category is still awaiting a real
  design system (`app/dashboard/page.tsx`)
- Admin endpoint to resolve queued "Something else" categories,
  upgrading a site off the neutral fallback system once a real one
  exists (`app/api/admin/custom-categories/route.ts`)

## What's real code but needs YOUR credentials/provisioning
None of this is stubbed logic — it's real API integrations that need
your accounts:
- Google OAuth client (Google Cloud Console)
- Vercel project + API token with domain-management scope
- Razorpay: three Plan objects (one per tier) + webhook secret
- `ADMIN_EMAILS` for the custom-category admin endpoint

## What's intentionally left as a documented next step
- **Photo compositing** (`lib/imageComposite.ts`) — background removal
  via remove.bg is wired and works with a real key; scene generation
  and the final compositing step are explicit `throw`s pointing at
  where an image-generation API and an image library (e.g. `sharp`)
  need to plug in. Not faked, because both need real infrastructure
  choices only you can make (which image model, self-hosted vs API).
- **New-user team invites** — `app/api/team/invite/route.ts` only
  invites people who already have an account; a real invite-by-email
  flow for brand-new users needs its own signup-with-invite-token path.
- **Custom-category regeneration** — resolving a queued custom category
  reassigns its design system but doesn't yet re-run copy generation
  against the new system's tone; flagged inline in the admin route.
- **Compliance review** — every line in `lib/compliance.ts` is
  placeholder text. A real regulatory/legal reviewer must populate this
  before it touches a real customer's site. No amount of code closes
  this gap — it's a human sign-off, by design.

## Running it
```bash
npm install
cp .env.example .env   # fill in all credentials — see the sections above
npx prisma migrate dev --name init
npm run dev
```

Full flow to test locally: `/` (pick categories, optional moodboard) →
`/onboarding` (Google sign-in, brand name, logo) → `/building` (real
progress) → `/preview/[siteId]` (view, edit conversationally, undo) →
`/domain` (real Vercel verification) → `/dashboard` (see all your
sites) → `/billing` (subscribe via Razorpay to unlock more sites).

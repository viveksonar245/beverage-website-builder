"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { CNAME_TARGET } from "@/lib/domainUtils";

interface VerificationChallenge {
  type: string;
  domain: string;
  value: string;
  reason: string;
}

type Status = "idle" | "checking" | "verified" | "dns_pending" | "needs_ownership_verification" | "error";

export default function DomainPage() {
  const params = useSearchParams();
  const siteId = params.get("siteId");
  const [domain, setDomain] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [challenges, setChallenges] = useState<VerificationChallenge[]>([]);

  async function checkStatus() {
    setStatus("checking");
    try {
      const res = await fetch("/api/domain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ siteId, domain }),
      });
      const data = await res.json();
      if (data.status === "needs_ownership_verification") {
        setChallenges(data.verification ?? []);
        setStatus("needs_ownership_verification");
      } else if (data.verified) {
        setStatus("verified");
      } else {
        setStatus("dns_pending");
      }
    } catch {
      setStatus("error");
    }
  }

  return (
    <main className="flex min-h-screen items-start justify-center bg-zinc-50 py-16">
      <div className="flex w-[620px] flex-col gap-7">
        <div>
          <h1 className="font-outfit text-2xl font-bold">Point your domain at your new site</h1>
          <p className="text-sm text-zinc-500">
            Own a domain already? Add one record and you&apos;re live.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          <label htmlFor="domain" className="text-xs font-semibold text-zinc-700">
            Your domain
          </label>
          <input
            id="domain"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            placeholder="yourbrand.com"
            className="rounded-lg border border-zinc-300 px-3.5 py-3 text-sm"
          />
        </div>

        <div className="flex flex-col gap-2 rounded-2xl border border-zinc-200 bg-white p-5 text-sm">
          <div className="font-semibold text-zinc-700">Add this record at your registrar</div>
          <div className="grid grid-cols-[80px_80px_1fr] gap-3 font-mono text-xs">
            <span className="rounded bg-zinc-100 px-2 py-1">CNAME</span>
            <span className="rounded bg-zinc-100 px-2 py-1">www</span>
            <span className="rounded bg-zinc-100 px-2 py-1">{CNAME_TARGET}</span>
          </div>
        </div>

        {status === "needs_ownership_verification" && (
          <div className="flex flex-col gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900">
            <div className="font-semibold">This domain needs one more record to prove ownership</div>
            {challenges.map((c, i) => (
              <div key={i} className="grid grid-cols-[60px_1fr] gap-3 font-mono text-xs">
                <span className="rounded bg-amber-100 px-2 py-1">{c.type}</span>
                <span className="rounded bg-amber-100 px-2 py-1 break-all">{c.value}</span>
              </div>
            ))}
            <p className="text-xs">{challenges[0]?.reason}</p>
          </div>
        )}

        {status === "verified" ? (
          <div className="rounded-2xl border border-green-200 bg-green-50 p-5 text-sm text-green-800">
            Domain verified · SSL certificate issued. Your site is live at https://{domain}
          </div>
        ) : (
          <button
            onClick={checkStatus}
            disabled={!domain || status === "checking"}
            className="self-start rounded-xl bg-indigo-600 px-6 py-3 text-sm font-semibold text-white disabled:opacity-40"
          >
            {status === "checking" ? "Checking…" : "Check status"}
          </button>
        )}

        {status === "dns_pending" && (
          <p className="text-xs text-zinc-500">
            DNS hasn&apos;t propagated yet — this can take a few minutes, sometimes longer depending
            on your registrar. Try again shortly.
          </p>
        )}
        {status === "error" && (
          <p className="text-xs text-red-600">Something went wrong checking your domain. Try again.</p>
        )}
      </div>
    </main>
  );
}

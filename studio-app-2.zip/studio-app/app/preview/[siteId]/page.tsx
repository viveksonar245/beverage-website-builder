import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import SitePreview from "@/components/SitePreview";
import EditBar from "@/components/EditBar";
import { GeneratedSite } from "@/lib/generateSite";
import Link from "next/link";
import { notFound } from "next/navigation";

export default async function PreviewPage({ params }: { params: { siteId: string } }) {
  const record = await prisma.site.findUnique({ where: { id: params.siteId } });
  if (!record) notFound();

  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  const isOwner = userId === record.userId;

  const site = record.content as unknown as GeneratedSite;
  const revisionCount = isOwner ? await prisma.siteRevision.count({ where: { siteId: record.id } }) : 0;

  return (
    <main>
      {isOwner && (
        <>
          <div className="flex items-center justify-between bg-zinc-900 px-7 py-3 text-sm text-white">
            <span className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-green-400" />
              AI generated preview · Design system: {site.system.label}
              {site.system.isFallback && " (temporary — a custom system is being designed)"}
            </span>
            <span className="flex items-center gap-3">
              <Link href="/dashboard" className="text-zinc-300">
                Your sites
              </Link>
              <Link href={`/domain?siteId=${record.id}`} className="rounded-lg bg-indigo-600 px-4 py-2 font-semibold">
                Connect domain &amp; publish
              </Link>
            </span>
          </div>
          {site.moodboardNote && (
            <div className="bg-amber-50 px-7 py-2 text-xs text-amber-800">{site.moodboardNote}</div>
          )}
          <EditBar siteId={record.id} hasHistory={revisionCount > 0} />
        </>
      )}
      <SitePreview site={site} />
    </main>
  );
}

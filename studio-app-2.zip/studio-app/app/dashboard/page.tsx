import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { DESIGN_SYSTEMS } from "@/lib/designSystems";
import Link from "next/link";
import { redirect } from "next/navigation";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) redirect("/onboarding");

  const sites = await prisma.site.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    include: {
      // surfaces whether a "Something else" site is still waiting on
      // a real design system — see CustomCategoryRequest
    },
  });

  const pendingUpgrades = await prisma.customCategoryRequest.findMany({
    where: { siteId: { in: sites.map((s) => s.id) }, status: { not: "resolved" } },
  });
  const pendingBySite = new Set(pendingUpgrades.map((p) => p.siteId));

  return (
    <main className="mx-auto max-w-4xl p-12">
      <div className="mb-8 flex items-center justify-between">
        <h1 className="font-outfit text-2xl font-bold">Your sites</h1>
        <Link href="/" className="rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white">
          + New site
        </Link>
      </div>

      {sites.length === 0 ? (
        <p className="text-sm text-zinc-500">You haven&apos;t built a site yet.</p>
      ) : (
        <div className="flex flex-col gap-3">
          {sites.map((site) => {
            const system = DESIGN_SYSTEMS[site.designSystemId] ?? null;
            const hasPendingUpgrade = pendingBySite.has(site.id);
            return (
              <div
                key={site.id}
                className="flex items-center justify-between rounded-2xl border border-zinc-200 p-5"
              >
                <div>
                  <div className="font-semibold">{site.brandName}</div>
                  <div className="text-xs text-zinc-500">
                    {system?.label ?? site.designSystemId}
                    {hasPendingUpgrade && (
                      <span className="ml-2 rounded-full bg-amber-100 px-2 py-0.5 text-amber-800">
                        Custom design in progress
                      </span>
                    )}
                    {site.domainVerified && site.domain && (
                      <span className="ml-2 rounded-full bg-green-100 px-2 py-0.5 text-green-800">
                        Live at {site.domain}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Link
                    href={`/preview/${site.id}`}
                    className="rounded-lg border border-zinc-300 px-4 py-2 text-sm font-semibold"
                  >
                    View / Edit
                  </Link>
                  <Link
                    href={`/domain?siteId=${site.id}`}
                    className="rounded-lg border border-zinc-300 px-4 py-2 text-sm font-semibold"
                  >
                    Domain
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
}

import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { normalizeHost } from "@/lib/domainUtils";
import { GeneratedSite } from "@/lib/generateSite";
import SitePreview from "@/components/SitePreview";

/**
 * This is what actually renders when a visitor hits popstar.com.
 * middleware.ts routes any non-platform Host here; this Node.js
 * server component does the real Prisma lookup (middleware can't —
 * it runs on the Edge runtime) matching the request's Host header
 * against Site.domain, and 404s if nothing's connected there.
 *
 * No owner chrome, no edit bar, no "AI preview" banner — this is the
 * plain public site, exactly what the brand's actual customers see.
 */
export default async function PublicSitePage() {
  const host = headers().get("host") ?? "";
  const domain = normalizeHost(host);

  const site = await prisma.site.findFirst({
    where: { domain, domainVerified: true },
  });

  if (!site) {
    notFound();
  }

  const content = site.content as unknown as GeneratedSite;
  return <SitePreview site={content} />;
}

"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { signIn, useSession } from "next-auth/react";
import { blendDesignSystems } from "@/lib/blend";
import { generateLogo } from "@/lib/generateLogo";
import MoodboardUpload from "@/components/MoodboardUpload";

export default function OnboardingPage() {
  const router = useRouter();
  const params = useSearchParams();
  const { data: session, status } = useSession();
  const [brandName, setBrandName] = useState("");
  const [loading, setLoading] = useState(false);
  const [logoMode, setLogoMode] = useState<"upload" | "generated">("upload");
  const [logoSvg, setLogoSvg] = useState<string | null>(null);
  const [moodboardAccent, setMoodboardAccent] = useState<string | null>(null);

  const selectedCategoryIds = (params.get("categories") ?? "").split(",").filter(Boolean);
  const customCategoryText = params.get("custom") ?? undefined;
  const system = blendDesignSystems(selectedCategoryIds);

  function handleGenerateLogo() {
    const { svg } = generateLogo(brandName || "Brand", system);
    setLogoSvg(svg);
    setLogoMode("generated");
  }

  async function startGeneration() {
    if (!brandName.trim() || !session?.user) return;
    setLoading(true);
    const jobId = crypto.randomUUID();
    router.push(`/building?jobId=${jobId}`); // navigate immediately; /building polls this jobId
    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      // No userId in the body — the API route reads it from the
      // server-side session, so a client can't forge another
      // user's id. See app/api/generate/route.ts.
      body: JSON.stringify({
        jobId,
        brandName,
        selectedCategoryIds,
        customCategoryText,
        logoSvg: logoMode === "generated" ? logoSvg : null,
        moodboardAccent,
      }),
    });
    const data = await res.json();
    if (!res.ok && data.code === "SITE_LIMIT_REACHED") {
      router.push(`/billing?reason=${encodeURIComponent(data.error)}`);
    } else if (!res.ok) {
      // /building is already polling and will surface job.error itself
      console.error(data.error);
    }
    // success case: /building's polling loop redirects to /preview/[siteId] on its own
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-zinc-50">
      <div className="flex w-[440px] flex-col gap-6 rounded-2xl border border-zinc-200 bg-white p-11">
        <div className="font-outfit text-xl font-bold">Studio</div>
        <div>
          <h1 className="font-outfit text-2xl font-bold">Build your website in one step</h1>
          <p className="mt-2 text-sm text-zinc-500">
            Sign in and confirm your brand name. Our agents handle the design, logo, copy and pages
            from here — you just connect the domain at the end.
          </p>
        </div>

        {status !== "authenticated" ? (
          <button
            onClick={() => signIn("google")}
            className="rounded-xl border border-zinc-300 py-3 text-sm font-semibold"
          >
            Continue with Google
          </button>
        ) : (
          <div className="flex items-center gap-2 rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-2.5 text-sm">
            <span className="h-2 w-2 rounded-full bg-green-500" />
            Signed in as {session.user.email}
          </div>
        )}

        <div className="flex flex-col gap-2">
          <label htmlFor="brandName" className="text-xs font-semibold text-zinc-700">
            Brand name
          </label>
          <input
            id="brandName"
            value={brandName}
            onChange={(e) => setBrandName(e.target.value)}
            placeholder="e.g. Popstar"
            className="rounded-lg border border-zinc-300 px-3.5 py-3 text-sm"
          />
        </div>

        <div className="flex flex-col gap-2">
          <span className="text-xs font-semibold text-zinc-700">Logo</span>
          {logoMode === "upload" ? (
            <>
              <label
                htmlFor="logoUpload"
                className="flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-zinc-300 p-4"
              >
                <input type="file" id="logoUpload" accept="image/*" className="hidden" />
                <span className="text-sm font-medium">Upload your logo</span>
              </label>
              <button
                onClick={handleGenerateLogo}
                disabled={!brandName.trim()}
                className="self-start text-xs font-semibold text-indigo-600 disabled:opacity-40"
              >
                Don&apos;t have a logo? Create one for us →
              </button>
            </>
          ) : (
            <div className="flex items-center gap-3 rounded-xl border border-zinc-200 p-3">
              {logoSvg && <div dangerouslySetInnerHTML={{ __html: logoSvg }} />}
              <button
                onClick={handleGenerateLogo}
                className="ml-auto rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-semibold"
              >
                Try another
              </button>
            </div>
          )}
        </div>

        <MoodboardUpload onColorExtracted={setMoodboardAccent} />

        <button
          disabled={loading || !brandName.trim() || status !== "authenticated"}
          onClick={startGeneration}
          className="rounded-xl bg-indigo-600 py-3.5 text-sm font-semibold text-white disabled:opacity-40"
        >
          Build my website →
        </button>
      </div>
    </main>
  );
}


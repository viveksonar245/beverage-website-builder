"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { PLANS, PlanId } from "@/lib/plans";

declare global {
  interface Window {
    Razorpay: new (options: Record<string, unknown>) => { open: () => void };
  }
}

function loadRazorpayScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.getElementById("razorpay-checkout-js")) return resolve();
    const script = document.createElement("script");
    script.id = "razorpay-checkout-js";
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Failed to load Razorpay checkout"));
    document.body.appendChild(script);
  });
}

export default function BillingPage() {
  const searchParams = useSearchParams();
  const [loadingPlan, setLoadingPlan] = useState<PlanId | null>(null);
  const [message, setMessage] = useState<string | null>(searchParams.get("reason"));

  async function subscribe(planId: PlanId) {
    setLoadingPlan(planId);
    setMessage(null);
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Checkout failed");

      await loadRazorpayScript();
      const rzp = new window.Razorpay({
        key: data.razorpayKeyId,
        subscription_id: data.subscriptionId,
        name: "Studio",
        description: `${PLANS[planId].label} plan`,
        // Activation is confirmed by the webhook, not this callback —
        // this just tells the user checkout succeeded from their side.
        handler: () => setMessage("Payment received — your plan activates within a minute."),
        modal: { ondismiss: () => setLoadingPlan(null) },
      });
      rzp.open();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoadingPlan(null);
    }
  }

  return (
    <main className="mx-auto max-w-4xl p-12">
      <h1 className="font-outfit text-2xl font-bold">Choose a plan</h1>
      <p className="mt-1 text-sm text-zinc-500">Upgrade any time. Cancel any time.</p>

      {message && <p className="mt-4 rounded-lg bg-indigo-50 p-3 text-sm text-indigo-800">{message}</p>}

      <div className="mt-8 grid grid-cols-3 gap-5">
        {Object.values(PLANS).map((plan) => (
          <div key={plan.id} className="flex flex-col gap-4 rounded-2xl border border-zinc-200 p-6">
            <div>
              <div className="font-outfit text-lg font-bold">{plan.label}</div>
              <div className="mt-1 text-2xl font-bold">
                ₹{(plan.priceInPaise / 100).toLocaleString("en-IN")}
                <span className="text-sm font-normal text-zinc-500">/mo</span>
              </div>
            </div>
            <p className="text-sm text-zinc-600">{plan.description}</p>
            <button
              onClick={() => subscribe(plan.id)}
              disabled={loadingPlan === plan.id}
              className="mt-auto rounded-xl bg-indigo-600 py-3 text-sm font-semibold text-white disabled:opacity-40"
            >
              {loadingPlan === plan.id ? "Loading…" : `Subscribe to ${plan.label}`}
            </button>
          </div>
        ))}
      </div>
    </main>
  );
}

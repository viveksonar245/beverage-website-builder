"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

const STAGES = [
  { key: "understanding", label: "Understanding your brand and category" },
  { key: "design_system", label: "Matching to your design system" },
  { key: "logo", label: "Preparing your logo and color palette" },
  { key: "copy", label: "Writing product copy and disclaimers" },
  { key: "assembling", label: "Assembling pages" },
];

/**
 * Polls real progress from /api/generate/status instead of showing a
 * fixed-time checklist — see app/api/generate/route.ts for the stages
 * this reflects.
 */
export default function BuildingPage() {
  const router = useRouter();
  const params = useSearchParams();
  const jobId = params.get("jobId");
  const [stage, setStage] = useState("understanding");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!jobId) return;
    const interval = setInterval(async () => {
      const res = await fetch(`/api/generate/status?jobId=${jobId}`);
      if (!res.ok) return;
      const data = await res.json();
      if (data.error) {
        setError(data.error);
        clearInterval(interval);
        return;
      }
      setStage(data.stage);
      if (data.stage === "done" && data.siteId) {
        clearInterval(interval);
        router.push(`/preview/${data.siteId}`);
      }
    }, 900);
    return () => clearInterval(interval);
  }, [jobId, router]);

  const currentIndex = STAGES.findIndex((s) => s.key === stage);

  return (
    <main className="flex min-h-screen items-center justify-center bg-zinc-50">
      <div className="flex w-[500px] flex-col gap-6 rounded-2xl border border-zinc-200 bg-white p-11">
        <div>
          <div className="font-outfit text-lg font-bold">Building your website</div>
          <div className="text-sm text-zinc-500">This usually takes under a minute.</div>
        </div>
        {error ? (
          <div className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</div>
        ) : (
          <ul className="flex flex-col gap-3 text-sm">
            {STAGES.map((s, i) => (
              <li
                key={s.key}
                className={
                  i < currentIndex
                    ? "text-zinc-700"
                    : i === currentIndex
                      ? "font-semibold text-zinc-900"
                      : "text-zinc-400"
                }
              >
                {i < currentIndex ? "✓ " : ""}
                {s.label}
                {i === currentIndex ? "…" : ""}
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}

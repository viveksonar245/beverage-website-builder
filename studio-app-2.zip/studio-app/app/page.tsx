import CategoryPicker from "@/components/CategoryPicker";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-zinc-50">
      <CategoryPicker />
    </main>
  );
}

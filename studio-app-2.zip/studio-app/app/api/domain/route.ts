import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { addDomainToProject, getDomainConfig } from "@/lib/vercelDomains";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const { siteId, domain } = await req.json();
  if (!siteId || !domain) {
    return NextResponse.json({ error: "Missing siteId or domain" }, { status: 400 });
  }

  const site = await prisma.site.findUnique({ where: { id: siteId } });
  if (!site || site.userId !== userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  try {
    const added = await addDomainToProject(domain);

    // Vercel asks for a TXT record when the domain is already claimed
    // elsewhere on the platform (a previous owner, or added to another
    // of your own projects) — this has to happen before DNS config is
    // even checked, so surface it distinctly from "DNS not pointed yet".
    if (added.verification.length > 0) {
      return NextResponse.json({
        verified: false,
        status: "needs_ownership_verification",
        verification: added.verification,
      });
    }

    const config = await getDomainConfig(domain);
    const verified = !config.misconfigured;

    if (verified) {
      await prisma.site.update({
        where: { id: siteId },
        data: { domain, domainVerified: true, publishedAt: new Date() },
      });
    }

    return NextResponse.json({
      verified,
      status: verified ? "verified" : "dns_pending",
    });
  } catch (err) {
    console.error("Domain verification failed:", err);
    return NextResponse.json({ error: "Domain check failed", verified: false }, { status: 500 });
  }
}

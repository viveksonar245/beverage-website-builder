import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { editSite } from "@/lib/editSite";
import { GeneratedSite } from "@/lib/generateSite";

const MAX_REVISIONS_KEPT = 20;

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const { siteId, instruction } = (await req.json()) as { siteId: string; instruction: string };
  if (!siteId || !instruction?.trim()) {
    return NextResponse.json({ error: "Missing siteId or instruction" }, { status: 400 });
  }

  const record = await prisma.site.findUnique({ where: { id: siteId } });
  if (!record || record.userId !== userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const currentContent = record.content as unknown as GeneratedSite;

  try {
    const { patch, touchedKeys } = await editSite(currentContent, instruction);

    if (touchedKeys.length === 0) {
      return NextResponse.json({ site: currentContent, touchedKeys: [] });
    }

    const updatedContent: GeneratedSite = { ...currentContent, ...patch };

    // Snapshot BEFORE overwriting, so undo can restore it. Kept as its
    // own table (not a JSON array on Site) so pruning old revisions
    // doesn't require rewriting the whole site row.
    await prisma.$transaction([
      prisma.siteRevision.create({
        data: { siteId, content: currentContent as unknown as object },
      }),
      prisma.site.update({
        where: { id: siteId },
        data: { content: updatedContent as unknown as object },
      }),
    ]);

    const oldRevisions = await prisma.siteRevision.findMany({
      where: { siteId },
      orderBy: { createdAt: "desc" },
      skip: MAX_REVISIONS_KEPT,
      select: { id: true },
    });
    if (oldRevisions.length > 0) {
      await prisma.siteRevision.deleteMany({ where: { id: { in: oldRevisions.map((r) => r.id) } } });
    }

    return NextResponse.json({ site: updatedContent, touchedKeys });
  } catch (err) {
    console.error("Edit failed:", err);
    return NextResponse.json({ error: "Edit failed" }, { status: 500 });
  }
}

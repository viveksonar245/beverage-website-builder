import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const { siteId } = (await req.json()) as { siteId: string };
  const record = await prisma.site.findUnique({ where: { id: siteId } });
  if (!record || record.userId !== userId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const lastRevision = await prisma.siteRevision.findFirst({
    where: { siteId },
    orderBy: { createdAt: "desc" },
  });

  if (!lastRevision) {
    return NextResponse.json({ error: "Nothing to undo" }, { status: 400 });
  }

  await prisma.$transaction([
    prisma.site.update({ where: { id: siteId }, data: { content: lastRevision.content as object } }),
    prisma.siteRevision.delete({ where: { id: lastRevision.id } }),
  ]);

  return NextResponse.json({ site: lastRevision.content });
}

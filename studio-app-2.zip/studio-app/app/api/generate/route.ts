import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { generateSite } from "@/lib/generateSite";
import { prisma } from "@/lib/db";
import { checkSiteLimit } from "@/lib/planLimits";

/**
 * Runs generation as a sequence of stages, writing progress to a
 * GenerationJob row after each one. /building polls
 * /api/generate/status?jobId=... to reflect real progress instead of
 * a static, fixed-time checklist. The jobId is generated client-side
 * (crypto.randomUUID()) and passed in, so the browser can start
 * polling the moment it navigates to /building, before this request
 * even finishes.
 */
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const body = await req.json();
  const { jobId, brandName, selectedCategoryIds, customCategoryText, logoSvg, moodboardAccent } = body as {
    jobId: string;
    brandName: string;
    selectedCategoryIds: string[];
    customCategoryText?: string;
    logoSvg?: string | null;
    moodboardAccent?: string | null;
  };

  if (!jobId || !brandName || !Array.isArray(selectedCategoryIds)) {
    return NextResponse.json({ error: "Missing jobId, brandName, or selectedCategoryIds" }, { status: 400 });
  }

  await prisma.generationJob.create({ data: { id: jobId, userId, stage: "understanding" } });

  const limitCheck = await checkSiteLimit(userId);
  if (!limitCheck.allowed) {
    await prisma.generationJob.update({ where: { id: jobId }, data: { stage: "failed", error: limitCheck.reason } });
    return NextResponse.json({ error: limitCheck.reason, code: "SITE_LIMIT_REACHED" }, { status: 402 });
  }

  try {
    await prisma.generationJob.update({ where: { id: jobId }, data: { stage: "design_system" } });
    await prisma.generationJob.update({ where: { id: jobId }, data: { stage: "logo" } });
    await prisma.generationJob.update({ where: { id: jobId }, data: { stage: "copy" } });

    const site = await generateSite({ brandName, selectedCategoryIds, customCategoryText, moodboardAccent });
    site.logoSvg = logoSvg ?? null;

    await prisma.generationJob.update({ where: { id: jobId }, data: { stage: "assembling" } });

    if (site.system.isFallback && customCategoryText) {
      // queued here; a real build processes this queue and upgrades
      // the site's design system once a human/agent resolves it — see
      // app/api/admin/custom-categories/route.ts
    }

    const record = await prisma.site.create({
      data: {
        userId,
        brandName,
        selectedCategoryIds: selectedCategoryIds.join(","),
        customCategoryText: customCategoryText ?? null,
        designSystemId: site.system.id,
        isFallbackSystem: site.system.isFallback,
        moodboardAccent: moodboardAccent ?? null,
        logoSvg: logoSvg ?? null,
        content: site as unknown as object,
        domain: null,
        domainVerified: false,
      },
    });

    if (site.system.isFallback && customCategoryText) {
      await prisma.customCategoryRequest.create({
        data: { siteId: record.id, customCategoryText, status: "pending" },
      });
    }

    await prisma.generationJob.update({ where: { id: jobId }, data: { stage: "done", siteId: record.id } });

    return NextResponse.json({ siteId: record.id, site });
  } catch (err) {
    console.error("Site generation failed:", err);
    await prisma.generationJob.update({
      where: { id: jobId },
      data: { stage: "failed", error: err instanceof Error ? err.message : "Unknown error" },
    });
    return NextResponse.json({ error: "Generation failed" }, { status: 500 });
  }
}

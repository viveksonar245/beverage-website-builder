import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { PLANS, PlanId } from "@/lib/plans";
import { createSubscription } from "@/lib/razorpay";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  const userEmail = session?.user?.email;
  if (!userId || !userEmail) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const { planId } = (await req.json()) as { planId: PlanId };
  const plan = PLANS[planId];
  if (!plan) {
    return NextResponse.json({ error: "Unknown plan" }, { status: 400 });
  }

  try {
    const subscription = await createSubscription(plan, userEmail);

    // Recorded as "created" now; the webhook flips it to "active" once
    // Razorpay confirms the first successful charge — see
    // app/api/billing/webhook/route.ts. Storing it now (rather than
    // only on webhook receipt) means we can look it up if the user
    // abandons checkout and retries.
    await prisma.subscription.create({
      data: {
        userId,
        planId: plan.id,
        razorpaySubscriptionId: subscription.id,
        status: "created",
      },
    });

    return NextResponse.json({
      subscriptionId: subscription.id,
      razorpayKeyId: process.env.RAZORPAY_KEY_ID,
    });
  } catch (err) {
    console.error("Failed to create subscription:", err);
    return NextResponse.json({ error: "Could not start checkout" }, { status: 500 });
  }
}

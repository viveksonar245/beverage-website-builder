import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { verifyWebhookSignature } from "@/lib/razorpay";

/**
 * Razorpay webhook events for subscriptions. This is the SOURCE OF
 * TRUTH for subscription status — the checkout route only records
 * "created"; everything after that (activation, renewals,
 * cancellation, payment failure) arrives here, asynchronously, and
 * may not correspond 1:1 with what the user just clicked.
 *
 * Configure this URL in Razorpay Dashboard → Settings → Webhooks,
 * subscribed to at least: subscription.activated, subscription.charged,
 * subscription.cancelled, subscription.completed, subscription.paused.
 */
export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-razorpay-signature");

  if (!signature || !verifyWebhookSignature(rawBody, signature)) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const event = JSON.parse(rawBody);
  const subscriptionEntity = event.payload?.subscription?.entity;

  if (!subscriptionEntity) {
    // Not a subscription-related event (could be a payment/order event
    // depending on what's enabled in the dashboard) — ack and ignore.
    return NextResponse.json({ received: true });
  }

  const razorpaySubscriptionId = subscriptionEntity.id as string;
  const currentPeriodEnd = subscriptionEntity.current_end
    ? new Date(subscriptionEntity.current_end * 1000)
    : null;

  const statusMap: Record<string, string> = {
    "subscription.activated": "active",
    "subscription.charged": "active",
    "subscription.pending": "pending",
    "subscription.halted": "paused",
    "subscription.paused": "paused",
    "subscription.resumed": "active",
    "subscription.cancelled": "cancelled",
    "subscription.completed": "completed",
  };

  const newStatus = statusMap[event.event as string];
  if (!newStatus) {
    return NextResponse.json({ received: true }); // event we don't act on
  }

  await prisma.subscription.updateMany({
    where: { razorpaySubscriptionId },
    data: { status: newStatus, currentPeriodEnd },
  });

  return NextResponse.json({ received: true });
}

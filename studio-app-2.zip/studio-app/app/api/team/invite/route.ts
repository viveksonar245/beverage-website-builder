import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

/**
 * Minimal viable team invite: Pro-tier plan required, invite by email
 * of an EXISTING user (a full build needs an actual invite-email flow
 * for people without an account yet — out of scope here, flagged
 * rather than faked). Adds the invitee to the caller's team, creating
 * one on first use.
 */
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const activeSubscription = await prisma.subscription.findFirst({
    where: { userId, status: "active" },
    orderBy: { createdAt: "desc" },
  });
  if (!activeSubscription || activeSubscription.planId !== "pro") {
    return NextResponse.json({ error: "Team seats require the Pro plan" }, { status: 402 });
  }

  const { inviteeEmail } = (await req.json()) as { inviteeEmail: string };
  const invitee = await prisma.user.findUnique({ where: { email: inviteeEmail } });
  if (!invitee) {
    // TODO: send an actual invite email with a signup link instead of
    // failing outright — this only handles inviting someone who
    // already has an account.
    return NextResponse.json({ error: "No Studio account found for that email yet" }, { status: 404 });
  }

  let team = await prisma.team.findFirst({ where: { ownerId: userId } });
  if (!team) {
    team = await prisma.team.create({
      data: {
        name: `${session?.user?.name ?? "My"}'s team`,
        ownerId: userId,
        members: { create: { userId, role: "owner" } },
      },
    });
  }

  await prisma.teamMember.upsert({
    where: { teamId_userId: { teamId: team.id, userId: invitee.id } },
    update: {},
    create: { teamId: team.id, userId: invitee.id, role: "member" },
  });

  return NextResponse.json({ teamId: team.id });
}

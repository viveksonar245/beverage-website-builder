import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { DESIGN_SYSTEMS } from "@/lib/designSystems";

/**
 * Not a public API — gate this behind whatever admin check your real
 * app uses (a role on User, an allowlist of emails, etc.). Left as a
 * single explicit TODO rather than faked, since a wrong guess here
 * would be a real security hole, not just an incomplete feature.
 */
function isAdmin(email: string | null | undefined): boolean {
  const admins = (process.env.ADMIN_EMAILS ?? "").split(",").map((e) => e.trim());
  return !!email && admins.includes(email);
}

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!isAdmin(session?.user?.email)) {
    return NextResponse.json({ error: "Not authorized" }, { status: 403 });
  }

  const pending = await prisma.customCategoryRequest.findMany({
    where: { status: { not: "resolved" } },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({ pending });
}

/**
 * Resolving a request assigns a real (presumably newly-built) design
 * system to the site and flips isFallbackSystem off, so the dashboard
 * and preview page stop showing "custom design in progress." A real
 * build would also notify the site's owner (email, in-app) here.
 */
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!isAdmin(session?.user?.email)) {
    return NextResponse.json({ error: "Not authorized" }, { status: 403 });
  }

  const { requestId, resolvedDesignSystemId } = (await req.json()) as {
    requestId: string;
    resolvedDesignSystemId: string;
  };

  if (!DESIGN_SYSTEMS[resolvedDesignSystemId]) {
    return NextResponse.json({ error: "Unknown design system id" }, { status: 400 });
  }

  const request = await prisma.customCategoryRequest.findUnique({ where: { id: requestId } });
  if (!request) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await prisma.$transaction([
    prisma.customCategoryRequest.update({ where: { id: requestId }, data: { status: "resolved" } }),
    prisma.site.update({
      where: { id: request.siteId },
      data: { designSystemId: resolvedDesignSystemId, isFallbackSystem: false },
    }),
    // TODO: re-run generateSite's copy pass against the new system so
    // the signature section / tone matches, rather than just retinting
    // the existing content. Left as a follow-up rather than silently
    // half-done here.
  ]);

  return NextResponse.json({ resolved: true });
}

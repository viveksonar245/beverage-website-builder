import { prisma } from "./db";

/**
 * A site is accessible to: its direct owner (userId), OR any member of
 * the team it belongs to (teamId). Direct ownership still works for
 * every plan; teams are additive, only relevant once a site has a
 * teamId (which only Pro-tier flows set — see app/api/team/invite).
 */
export async function userCanAccessSite(userId: string, site: { userId: string; teamId: string | null }) {
  if (site.userId === userId) return true;
  if (!site.teamId) return false;

  const membership = await prisma.teamMember.findUnique({
    where: { teamId_userId: { teamId: site.teamId, userId } },
  });
  return !!membership;
}

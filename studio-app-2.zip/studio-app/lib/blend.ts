import { DESIGN_SYSTEMS, FALLBACK_SYSTEM_ID, DesignSystem } from "./designSystems";

export interface BlendedSystem extends DesignSystem {
  /** ids that contributed, in selection order */
  sourceIds: string[];
  /** true if this came from the neutral fallback, not a real match */
  isFallback: boolean;
}

/**
 * Combine 1–N selected category ids into one renderable system.
 *
 * Rule (see conversation notes): PRIMARY + SECONDARY, never a true
 * average of everything selected.
 *  - 1st selected id  -> primary: owns layout, typography, spacing,
 *    image treatment, and the base palette.
 *  - 2nd selected id  -> secondary: contributes only its accent color
 *    (blended in, not replacing the primary's) and its signature
 *    section, appended to the primary's layout.
 *  - 3rd+ selected ids -> visual influence stops here. They still get
 *    returned in sourceIds so the copy-generation prompt can lean the
 *    tone/keywords toward them, but they never touch color or layout.
 *  - Unknown / custom category ("something else") -> immediate neutral
 *    fallback system, flagged isFallback so the UI can show the
 *    "we're designing something custom for you" messaging and queue
 *    the real build.
 */
export function blendDesignSystems(selectedIds: string[]): BlendedSystem {
  const known = selectedIds.filter((id) => DESIGN_SYSTEMS[id]);

  if (known.length === 0) {
    const fallback = DESIGN_SYSTEMS[FALLBACK_SYSTEM_ID];
    return { ...fallback, sourceIds: selectedIds, isFallback: true };
  }

  const primary = DESIGN_SYSTEMS[known[0]];
  const secondary = known[1] ? DESIGN_SYSTEMS[known[1]] : null;

  if (!secondary) {
    return { ...primary, sourceIds: known, isFallback: false };
  }

  return {
    ...primary,
    colors: {
      ...primary.colors,
      // secondary contributes ONLY its accent, layered onto the
      // primary's palette — background/surface/ink/muted stay primary's
      accent: secondary.colors.accent,
      accentSoft: secondary.colors.accentSoft,
    },
    // secondary's signature section gets appended after the primary's
    // own content, handled by the site-generation prompt (see
    // lib/generateSite.ts) — it never overrides the primary's own
    // signature section if it has one.
    signatureSection:
      primary.signatureSection !== "none" ? primary.signatureSection : secondary.signatureSection,
    sourceIds: known,
    isFallback: false,
  };
}

export function conflictNote(selectedIds: string[]): string | null {
  const known = selectedIds.filter((id) => DESIGN_SYSTEMS[id]);
  if (known.length < 2) return null;
  const primary = DESIGN_SYSTEMS[known[0]];
  const secondary = DESIGN_SYSTEMS[known[1]];

  // crude but honest heuristic: dark vs light background = visual clash
  const clash = primary.colors.background !== secondary.colors.background;
  if (!clash) return null;

  return `These styles pull in different directions — we'll lean toward ${primary.label} and use ${secondary.label} as an accent.`;
}

export type PlanId = "starter" | "growth" | "pro";

export interface Plan {
  id: PlanId;
  label: string;
  priceInPaise: number; // INR, smallest unit — Razorpay amounts are always in paise
  siteLimit: number; // Infinity for unlimited
  description: string;
  /** The corresponding Plan created in the Razorpay dashboard (Plans → Create Plan). */
  razorpayPlanIdEnvVar: string;
}

export const PLANS: Record<PlanId, Plan> = {
  starter: {
    id: "starter",
    label: "Starter",
    priceInPaise: 149900, // ₹1,499/mo
    siteLimit: 1,
    description: "One site, AI-generated pages, connect your own domain.",
    razorpayPlanIdEnvVar: "RAZORPAY_PLAN_STARTER",
  },
  growth: {
    id: "growth",
    label: "Growth",
    priceInPaise: 599900, // ₹5,999/mo
    siteLimit: 5,
    description: "Product catalog sync, subscription pages, basic analytics.",
    razorpayPlanIdEnvVar: "RAZORPAY_PLAN_GROWTH",
  },
  pro: {
    id: "pro",
    label: "Pro",
    priceInPaise: 1500000, // ₹15,000/mo
    siteLimit: Infinity,
    description: "Multiple sites, team seats, compliance library, priority support.",
    razorpayPlanIdEnvVar: "RAZORPAY_PLAN_PRO",
  },
};

// Sites a user gets before ever subscribing — lets someone try the
// product (pick categories, sign in, generate a site) before paying,
// without requiring a plan just to see output.
export const FREE_TRIAL_SITE_LIMIT = 1;

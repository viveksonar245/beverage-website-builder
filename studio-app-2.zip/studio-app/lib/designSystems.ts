/**
 * Design system token library.
 *
 * Each category is stored as DECOMPOSED tokens (color, type, spacing,
 * image treatment, signature section) — never as a monolithic template.
 * This is what makes category combinations possible: we can take the
 * primary category's layout/type/spacing and layer a secondary
 * category's accent color + one signature section on top, without
 * building a new system for every possible pairing.
 *
 * See lib/blend.ts for how these get combined at generation time.
 */

export type SignatureSection =
  | "socialProofCollage" // Youth & Party
  | "ingredientBreakdown" // Juice & Functional
  | "tastingNotes" // RTD Tea & Coffee
  | "labResultsBadge" // Premium & Craft Mixers / Protein
  | "originStory" // Coconut & Natural Water / Kombucha
  | "none";

export interface DesignSystem {
  id: string;
  label: string;
  description: string;
  colors: {
    background: string;
    surface: string;
    ink: string;
    muted: string;
    accent: string;
    accentSoft: string;
  };
  typography: {
    display: string; // headline font
    body: string; // body font
    displayWeight: number;
    letterSpacing: string; // e.g. "0.02em", "-0.01em", "normal"
  };
  spacing: {
    density: "airy" | "balanced" | "tight"; // controls section padding scale
    radius: number; // px, corner rounding
  };
  imageTreatment: {
    style: "bright-natural" | "high-contrast" | "warm-editorial" | "moody-cinematic" | "saturated-social";
    shadow: "none" | "soft" | "hard";
  };
  signatureSection: SignatureSection;
  /**
   * SVG path data for this category's logo mark, or null for a
   * type-only wordmark (e.g. Premium & Craft Mixers, which per the
   * design brief uses refined type + a thin rule line, no icon).
   * Kept deliberately abstract/geometric — never a literal product
   * (bottle/can) render, per the logo safety rule.
   */
  markPath: string | null;
}

export const DESIGN_SYSTEMS: Record<string, DesignSystem> = {
  energy: {
    id: "energy",
    label: "Energy Drinks",
    description: "Bold, high-contrast, kinetic",
    colors: {
      background: "#0B0B0F",
      surface: "#16161D",
      ink: "#F4F4F5",
      muted: "#A1A1AA",
      accent: "#F97316",
      accentSoft: "#7C2D12",
    },
    typography: { display: "Outfit", body: "IBM Plex Sans", displayWeight: 700, letterSpacing: "-0.01em" },
    spacing: { density: "tight", radius: 8 },
    imageTreatment: { style: "high-contrast", shadow: "hard" },
    signatureSection: "none",
    markPath: "M13 2L3 14h8l-1 8 10-12h-8l1-8z",
  },
  hydration: {
    id: "hydration",
    label: "Hydration & Electrolytes",
    description: "Clean, athletic, generous whitespace",
    colors: {
      background: "#FFFFFF",
      surface: "#F8FAFC",
      ink: "#0F172A",
      muted: "#64748B",
      accent: "#0F766E",
      accentSoft: "#F0FDFA",
    },
    typography: { display: "Outfit", body: "IBM Plex Sans", displayWeight: 600, letterSpacing: "0.01em" },
    spacing: { density: "airy", radius: 20 },
    imageTreatment: { style: "bright-natural", shadow: "soft" },
    signatureSection: "none",
    markPath: "M12 2s6 6.5 6 11a6 6 0 1 1-12 0c0-4.5 6-11 6-11z",
  },
  tea_coffee: {
    id: "tea_coffee",
    label: "RTD Tea & Coffee",
    description: "Warm, editorial, unhurried",
    colors: {
      background: "#FAF6EF",
      surface: "#FFFFFF",
      ink: "#3B2A1E",
      muted: "#8A7862",
      accent: "#92400E",
      accentSoft: "#FEF3E2",
    },
    typography: { display: "Fraunces", body: "IBM Plex Sans", displayWeight: 600, letterSpacing: "normal" },
    spacing: { density: "balanced", radius: 14 },
    imageTreatment: { style: "warm-editorial", shadow: "soft" },
    signatureSection: "tastingNotes",
    markPath: "M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z",
  },
  juice_functional: {
    id: "juice_functional",
    label: "Juice & Functional",
    description: "Ingredient-forward, natural, honest",
    colors: {
      background: "#FFFDF7",
      surface: "#FFFFFF",
      ink: "#1F2937",
      muted: "#6B7280",
      accent: "#65A30D",
      accentSoft: "#F0FDF4",
    },
    typography: { display: "Outfit", body: "IBM Plex Sans", displayWeight: 600, letterSpacing: "normal" },
    spacing: { density: "balanced", radius: 16 },
    imageTreatment: { style: "bright-natural", shadow: "soft" },
    signatureSection: "ingredientBreakdown",
    markPath: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 3v18M3 12h18",
  },
  youth_party: {
    id: "youth_party",
    label: "Youth & Party",
    description: "Loud, fun, shareable",
    colors: {
      background: "#FFFFFF",
      surface: "#FDF4FF",
      ink: "#18181B",
      muted: "#71717A",
      accent: "#DB2777",
      accentSoft: "#FCE7F3",
    },
    typography: { display: "Outfit", body: "IBM Plex Sans", displayWeight: 700, letterSpacing: "normal" },
    spacing: { density: "tight", radius: 24 },
    imageTreatment: { style: "saturated-social", shadow: "hard" },
    signatureSection: "socialProofCollage",
    markPath: "M12 2l2.9 6.5L22 9.3l-5 4.9 1.2 7.1L12 17.8l-6.2 3.5L7 14.2 2 9.3l7.1-.8z",
  },
  premium_mixers: {
    id: "premium_mixers",
    label: "Premium & Craft Mixers",
    description: "Refined, understated, cinematic",
    colors: {
      background: "#0E1210",
      surface: "#171C19",
      ink: "#F4F4F0",
      muted: "#9CA69F",
      accent: "#C9A24B",
      accentSoft: "#2A2416",
    },
    typography: { display: "Fraunces", body: "IBM Plex Sans", displayWeight: 500, letterSpacing: "0.02em" },
    spacing: { density: "airy", radius: 4 },
    imageTreatment: { style: "moody-cinematic", shadow: "hard" },
    signatureSection: "labResultsBadge",
    markPath: null, // type-only — refined type + a thin rule line, no icon
  },
  protein_nutrition: {
    id: "protein_nutrition",
    label: "Protein & Nutrition",
    description: "Performance-driven, credible, direct",
    colors: {
      background: "#0F172A",
      surface: "#1E293B",
      ink: "#F1F5F9",
      muted: "#94A3B8",
      accent: "#38BDF8",
      accentSoft: "#0C4A6E",
    },
    typography: { display: "Outfit", body: "IBM Plex Sans", displayWeight: 700, letterSpacing: "-0.01em" },
    spacing: { density: "tight", radius: 10 },
    imageTreatment: { style: "high-contrast", shadow: "hard" },
    signatureSection: "labResultsBadge",
    markPath: "M6 7v10M18 7v10M2 10v4M22 10v4M6 12h12",
  },
  kombucha_probiotic: {
    id: "kombucha_probiotic",
    label: "Kombucha & Probiotic",
    description: "Earthy, artisanal, slow",
    colors: {
      background: "#F5F1E8",
      surface: "#FFFFFF",
      ink: "#3F3A2E",
      muted: "#8C8471",
      accent: "#A16207",
      accentSoft: "#FEF9C3",
    },
    typography: { display: "Fraunces", body: "IBM Plex Sans", displayWeight: 500, letterSpacing: "normal" },
    spacing: { density: "balanced", radius: 12 },
    imageTreatment: { style: "warm-editorial", shadow: "soft" },
    signatureSection: "originStory",
    markPath: "M8 3h8v3a4 4 0 0 1-1 2.6V19a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2V8.6A4 4 0 0 1 8 6V3z",
  },
  sparkling_soda: {
    id: "sparkling_soda",
    label: "Sparkling & Soda",
    description: "Bright, playful, effervescent",
    colors: {
      background: "#FFFFFF",
      surface: "#EFF6FF",
      ink: "#1E293B",
      muted: "#64748B",
      accent: "#2563EB",
      accentSoft: "#DBEAFE",
    },
    typography: { display: "Outfit", body: "IBM Plex Sans", displayWeight: 600, letterSpacing: "normal" },
    spacing: { density: "balanced", radius: 20 },
    imageTreatment: { style: "bright-natural", shadow: "soft" },
    signatureSection: "none",
    markPath: "M12 12m-8 0a8 8 0 1 0 16 0a8 8 0 1 0 -16 0",
  },
  coconut_natural: {
    id: "coconut_natural",
    label: "Coconut & Natural Water",
    description: "Tropical, minimal, sourced",
    colors: {
      background: "#FBFAF7",
      surface: "#FFFFFF",
      ink: "#2C2B26",
      muted: "#7C7A70",
      accent: "#0D9488",
      accentSoft: "#F0FDFA",
    },
    typography: { display: "Outfit", body: "IBM Plex Sans", displayWeight: 600, letterSpacing: "0.01em" },
    spacing: { density: "airy", radius: 18 },
    imageTreatment: { style: "bright-natural", shadow: "soft" },
    signatureSection: "originStory",
    markPath: "M12 2C7 6 4 10 4 14a8 8 0 0 0 16 0c0-4-3-8-8-12z",
  },
  nonalc_spirits: {
    id: "nonalc_spirits",
    label: "Non-Alcoholic Spirits",
    description: "Sophisticated, adult, restrained",
    colors: {
      background: "#141312",
      surface: "#1F1D1B",
      ink: "#F5F3F0",
      muted: "#A8A29E",
      accent: "#B45309",
      accentSoft: "#3A2A18",
    },
    typography: { display: "Fraunces", body: "IBM Plex Sans", displayWeight: 500, letterSpacing: "0.01em" },
    spacing: { density: "airy", radius: 6 },
    imageTreatment: { style: "moody-cinematic", shadow: "hard" },
    signatureSection: "tastingNotes",
    markPath: "M4 4h16L12 13v7M8 20h8",
  },
};

// The safe, neutral fallback used immediately for "Something else" /
// custom categories while a real system is designed (see lib/blend.ts).
export const FALLBACK_SYSTEM_ID = "juice_functional";

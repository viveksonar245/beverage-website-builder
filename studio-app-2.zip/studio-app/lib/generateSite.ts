import Anthropic from "@anthropic-ai/sdk";
import { blendDesignSystems, BlendedSystem } from "./blend";
import { getComplianceBlocks } from "./compliance";
import { blendMoodboardAccent } from "./moodboard";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export interface SignatureSectionContent {
  kind: string; // matches BlendedSystem.signatureSection
  title: string;
  items: { label: string; body: string }[];
}

export interface GeneratedSite {
  brandName: string;
  system: BlendedSystem;
  logoSvg?: string | null;
  moodboardNote?: string | null;
  hero: { headline: string; subcopy: string; primaryCta: string; secondaryCta: string };
  features: { title: string; body: string }[];
  testimonial: { quote: string; attribution: string };
  cta: { headline: string; buttonLabel: string };
  signatureSection?: SignatureSectionContent | null;
  compliance: { productPage: string[]; footer: string[] };
}

const SIGNATURE_SECTION_PROMPTS: Record<string, string> = {
  ingredientBreakdown:
    'an "What\'s inside" section: a title and 3-4 items, each a real ingredient name (or [INGREDIENT] placeholder) with a one-line honest description of what it does',
  tastingNotes:
    'a "Tasting notes" section: a title and 3 items, each a flavor/aroma note (e.g. "Citrus peel", "Toasted oak") with a one-line sensory description',
  socialProofCollage:
    'a "As seen with" section: a title and 3 items, each a short social-proof style caption (e.g. an occasion or setting the drink fits) — no invented follower counts or fake review numbers',
  labResultsBadge:
    'a "By the numbers" section: a title and 3 items, each a credible, non-medical-claim product attribute (e.g. "Third-party lab tested", "Batch-verified potency") with a one-line explanation — no specific health claims',
  originStory:
    'an "Where it comes from" section: a title and 3 items, each a short origin/sourcing fact (region, farming practice, harvest note) with a one-line description',
};

export async function generateSite(params: {
  brandName: string;
  selectedCategoryIds: string[];
  customCategoryText?: string;
  moodboardAccent?: string | null;
}): Promise<GeneratedSite> {
  const { brandName, selectedCategoryIds, customCategoryText, moodboardAccent } = params;
  let system = blendDesignSystems(selectedCategoryIds);
  let moodboardNote: string | null = null;

  if (moodboardAccent) {
    const blended = blendMoodboardAccent(system.colors.accent, moodboardAccent);
    system = { ...system, colors: { ...system.colors, accent: blended.accent, accentSoft: blended.accentSoft } };
    moodboardNote = blended.note;
  }

  const categoryContext = customCategoryText
    ? `a custom, not-yet-catalogued category described by the founder as: "${customCategoryText}"`
    : `the ${system.sourceIds.map(() => system.label).join(" / ")} beverage category`;

  const signatureInstruction = system.signatureSection !== "none" && SIGNATURE_SECTION_PROMPTS[system.signatureSection]
    ? `\n\nAlso write ${SIGNATURE_SECTION_PROMPTS[system.signatureSection]}. Include it in the JSON as "signatureSection": { "title": "...", "items": [ { "label": "...", "body": "..." } ] }.`
    : "";

  const prompt = `You are writing marketing copy for a beverage brand's new website.

Brand name: ${brandName}
Category: ${categoryContext}
Tone: match the mood "${system.description}"

Write ONLY marketing copy — no nutrition facts, no health claims requiring
regulatory backing, no legal disclaimers, no invented statistics or fake
review counts. Where a concrete fact is missing (price, exact ingredient),
use a bracketed placeholder like [PRICE] instead of inventing one.${signatureInstruction}

Respond with ONLY a JSON object, no markdown fences, no preamble, matching
exactly this shape (omit "signatureSection" entirely if not instructed above):
{
  "hero": { "headline": "...", "subcopy": "...", "primaryCta": "...", "secondaryCta": "..." },
  "features": [ { "title": "...", "body": "..." }, { "title": "...", "body": "..." }, { "title": "...", "body": "..." } ],
  "testimonial": { "quote": "...", "attribution": "[Customer name]" },
  "cta": { "headline": "...", "buttonLabel": "..." }
}`;

  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1500,
    messages: [{ role: "user", content: prompt }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("No text content returned from generation");
  }

  const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
  const copy = JSON.parse(cleaned) as Pick<GeneratedSite, "hero" | "features" | "testimonial" | "cta"> & {
    signatureSection?: { title: string; items: { label: string; body: string }[] };
  };

  const compliance = {
    productPage: getComplianceBlocks(system.id, "productPage").map((b) => b.text),
    footer: getComplianceBlocks(system.id, "footer").map((b) => b.text),
  };

  const signatureSection: SignatureSectionContent | null =
    copy.signatureSection && system.signatureSection !== "none"
      ? { kind: system.signatureSection, title: copy.signatureSection.title, items: copy.signatureSection.items }
      : null;

  return { brandName, system, moodboardNote, hero: copy.hero, features: copy.features, testimonial: copy.testimonial, cta: copy.cta, signatureSection, compliance };
}

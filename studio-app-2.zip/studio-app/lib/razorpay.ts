import Razorpay from "razorpay";
import crypto from "crypto";
import { Plan } from "./plans";

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID as string,
  key_secret: process.env.RAZORPAY_KEY_SECRET as string,
});

/**
 * Creates a Razorpay subscription for the given plan. Razorpay plans
 * (the price + billing interval) are created once in the Razorpay
 * dashboard, not via API here — plan.razorpayPlanIdEnvVar points at
 * the env var holding that plan's id (see .env.example).
 *
 * total_count is the number of billing cycles before Razorpay
 * auto-stops the subscription — 120 monthly cycles (~10 years) is
 * effectively "until cancelled" without leaving it literally
 * infinite, which Razorpay's API doesn't accept.
 */
export async function createSubscription(plan: Plan, customerEmail: string) {
  const razorpayPlanId = process.env[plan.razorpayPlanIdEnvVar];
  if (!razorpayPlanId) {
    throw new Error(`Missing env var ${plan.razorpayPlanIdEnvVar} for plan ${plan.id}`);
  }

  return razorpay.subscriptions.create({
    plan_id: razorpayPlanId,
    customer_notify: 1,
    total_count: 120,
    notes: { planId: plan.id, customerEmail },
  });
}

/**
 * Verifies a webhook payload actually came from Razorpay, using the
 * webhook secret configured alongside the webhook URL in the
 * dashboard (Settings → Webhooks) — NOT the same as key_secret.
 */
export function verifyWebhookSignature(rawBody: string, signature: string): boolean {
  const expected = crypto
    .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET as string)
    .update(rawBody)
    .digest("hex");
  return expected === signature;
}

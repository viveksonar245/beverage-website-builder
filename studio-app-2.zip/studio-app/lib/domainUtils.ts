/** The CNAME target every customer domain should point at. */
export const CNAME_TARGET = process.env.NEXT_PUBLIC_VERCEL_CNAME_TARGET || "cname.vercel-dns.com";

/**
 * Strips a leading "www." so a visitor hitting either popstar.com or
 * www.popstar.com matches the same stored Site.domain value, whichever
 * form the customer entered on /domain.
 */
export function normalizeHost(host: string): string {
  return host.replace(/^www\./, "").split(":")[0].toLowerCase();
}

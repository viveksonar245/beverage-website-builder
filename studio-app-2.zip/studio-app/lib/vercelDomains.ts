/**
 * Thin wrapper around Vercel's Domains API. Requires:
 *   VERCEL_TOKEN       — an API token (Account Settings → Tokens)
 *   VERCEL_PROJECT_ID  — this project's id or name
 *   VERCEL_TEAM_ID     — optional, only if the project lives under a team
 *
 * Docs: https://vercel.com/docs/rest-api/reference/endpoints/domains
 *
 * Cloudflare for SaaS is the equivalent if you'd rather not host on
 * Vercel — same shape (add hostname, poll a config/verification
 * status, SSL is issued automatically once DNS is correct) but
 * different endpoints. Swap this file, not the route that calls it.
 */

const API_BASE = "https://api.vercel.com";

function authHeaders() {
  return { Authorization: `Bearer ${process.env.VERCEL_TOKEN}`, "Content-Type": "application/json" };
}

function teamQuery() {
  return process.env.VERCEL_TEAM_ID ? `?teamId=${process.env.VERCEL_TEAM_ID}` : "";
}

export interface VerificationChallenge {
  type: string; // e.g. "TXT"
  domain: string;
  value: string;
  reason: string;
}

export interface AddDomainResult {
  alreadyExists: boolean;
  verified: boolean;
  verification: VerificationChallenge[]; // present if Vercel needs proof of ownership
}

/**
 * Attach a domain to the project. Idempotent — if it's already
 * attached (Vercel returns 409), we treat that as success and fall
 * through to reading its current status instead of erroring.
 */
export async function addDomainToProject(domain: string): Promise<AddDomainResult> {
  const projectId = process.env.VERCEL_PROJECT_ID;
  const res = await fetch(`${API_BASE}/v10/projects/${projectId}/domains${teamQuery()}`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({ name: domain }),
  });

  if (res.status === 409) {
    return { alreadyExists: true, verified: true, verification: [] };
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(`Vercel addDomain failed (${res.status}): ${JSON.stringify(body)}`);
  }

  const data = await res.json();
  return {
    alreadyExists: false,
    verified: data.verified ?? false,
    verification: data.verification ?? [],
  };
}

export interface DomainConfig {
  misconfigured: boolean;
}

/** Checks whether the domain's DNS is actually pointed correctly yet. */
export async function getDomainConfig(domain: string): Promise<DomainConfig> {
  const res = await fetch(`${API_BASE}/v6/domains/${domain}/config${teamQuery()}`, {
    headers: authHeaders(),
  });
  if (!res.ok) {
    throw new Error(`Vercel getDomainConfig failed (${res.status})`);
  }
  const data = await res.json();
  return { misconfigured: !!data.misconfigured };
}

export { CNAME_TARGET, normalizeHost } from "./domainUtils";

/**
 * Client-side moodboard extraction (see components/MoodboardUpload.tsx)
 * hands us a single dominant hex color sampled from the user's
 * reference images. This nudges the resolved design system's accent
 * toward it — it never replaces the system's layout, typography, or
 * background, matching the "moodboard as a modifier, not a
 * replacement" rule from the design brief.
 */

function hexToHsl(hex: string): [number, number, number] {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  const l = (max + min) / 2;
  const d = max - min;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  if (d !== 0) {
    switch (max) {
      case r:
        h = ((g - b) / d) % 6;
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      default:
        h = (r - g) / d + 4;
    }
    h *= 60;
    if (h < 0) h += 360;
  }
  return [h, s, l];
}

function hslToHex(h: number, s: number, l: number): string {
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let [r, g, b] = [0, 0, 0];
  if (h < 60) [r, g, b] = [c, x, 0];
  else if (h < 120) [r, g, b] = [x, c, 0];
  else if (h < 180) [r, g, b] = [0, c, x];
  else if (h < 240) [r, g, b] = [0, x, c];
  else if (h < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  const toHex = (v: number) =>
    Math.round((v + m) * 255)
      .toString(16)
      .padStart(2, "0");
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

export interface MoodboardBlendResult {
  accent: string;
  accentSoft: string;
  note: string | null;
}

/** Hue distance beyond which we flag the mismatch instead of applying it silently. */
const HUE_CONFLICT_THRESHOLD = 90;

export function blendMoodboardAccent(baseAccentHex: string, moodboardHex: string): MoodboardBlendResult {
  const [baseHue, baseSat, baseLight] = hexToHsl(baseAccentHex);
  const [moodHue] = hexToHsl(moodboardHex);

  const hueDiff = Math.min(Math.abs(baseHue - moodHue), 360 - Math.abs(baseHue - moodHue));

  if (hueDiff > HUE_CONFLICT_THRESHOLD) {
    // Guardrail: don't let a wildly different moodboard drag a
    // category's system off-brand — keep the system's own accent and
    // just say why.
    return {
      accent: baseAccentHex,
      accentSoft: baseAccentHex,
      note: "Your reference images lean toward a different palette than this category typically uses — we kept the category's own colors so the site stays legible and on-brand. You can still apply moodboard colors manually later.",
    };
  }

  // Nudge hue toward the moodboard's, keep the base system's
  // saturation/lightness so contrast and legibility stay intact.
  const blendedHue = baseHue + (moodHue - baseHue) * 0.4;
  const accent = hslToHex(blendedHue, baseSat, baseLight);
  const accentSoft = hslToHex(blendedHue, Math.max(baseSat - 0.3, 0.1), Math.min(baseLight + 0.35, 0.95));

  return { accent, accentSoft, note: null };
}

/**
 * Implements the hybrid image strategy from the architecture doc:
 *   - Real product photos (uploaded by the user) — never AI-generated,
 *     since a generative model will hallucinate label text and
 *     ingredient claims.
 *   - Background/lifestyle imagery — AI-generated is fine here, since
 *     it never needs to depict the actual product.
 *   - Compositing the two — background removal on the real photo, then
 *     placed over a generated or curated scene.
 *
 * This file wraps two real, swappable services rather than
 * implementing image processing from scratch:
 *   - Background removal: remove.bg's API (or Photoroom, same shape)
 *   - Scene generation: any image model API you have access to
 *     (left as a TODO call — this repo doesn't include image
 *     generation credentials, unlike the text generation in
 *     lib/generateSite.ts which reuses ANTHROPIC_API_KEY)
 *
 * NEITHER of these has real credentials wired in this scaffold — set
 * REMOVE_BG_API_KEY to make background removal work; scene generation
 * needs an image-model API of your choosing plugged into
 * generateSceneBackground below.
 */

export async function removeBackground(imageBuffer: Buffer): Promise<Buffer> {
  const apiKey = process.env.REMOVE_BG_API_KEY;
  if (!apiKey) {
    throw new Error("REMOVE_BG_API_KEY not set — background removal needs a real API key");
  }

  const formData = new FormData();
  formData.append("image_file", new Blob([imageBuffer]));
  formData.append("size", "auto");

  const res = await fetch("https://api.remove.bg/v1.0/removebg", {
    method: "POST",
    headers: { "X-Api-Key": apiKey },
    body: formData,
  });

  if (!res.ok) {
    throw new Error(`Background removal failed (${res.status})`);
  }

  return Buffer.from(await res.arrayBuffer());
}

/**
 * TODO: wire this to an actual image-generation API. The prompt shape
 * below deliberately excludes the product itself — it only describes
 * mood/setting, per the "never AI-generate the product" rule — so
 * whichever model you plug in just needs to accept a text prompt and
 * return image bytes.
 */
export async function generateSceneBackground(params: {
  designSystemMood: string; // e.g. system.description from lib/designSystems.ts
  imageStyle: string; // e.g. system.imageTreatment.style
}): Promise<Buffer> {
  throw new Error(
    `generateSceneBackground not implemented — plug in an image generation API here. ` +
      `Requested mood: "${params.designSystemMood}", style: "${params.imageStyle}"`
  );
}

/**
 * Composites a background-removed product photo over a scene image.
 * Left unimplemented (rather than faked) because real compositing
 * needs an actual image library (sharp, or a canvas in a serverless
 * function with the right runtime) — this is the seam where that
 * plugs in once the two pieces above return real image buffers.
 */
export async function compositeProductOntoScene(_productPng: Buffer, _sceneImage: Buffer): Promise<Buffer> {
  throw new Error("compositeProductOntoScene not implemented — needs an image library such as sharp");
}

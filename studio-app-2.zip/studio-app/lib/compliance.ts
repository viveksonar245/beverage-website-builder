/**
 * Compliance / disclaimer library.
 *
 * IMPORTANT: text in this file is retrieved and inserted verbatim —
 * it is NEVER generated or paraphrased by the LLM. This is the core
 * safety rule from the architecture: regulatory language is treated
 * as data, not creative output, to keep it accurate and consistent
 * even as the model or prompts change over time.
 *
 * This is a starter set for illustration only — every line here needs
 * review by an actual regulatory/legal advisor (FSSAI in India, FDA in
 * the US, etc.) before this goes anywhere near a real customer site.
 * Treat this file as the seam where that review plugs in, versioned,
 * so updates to regulation don't require touching generation code.
 */

export interface ComplianceBlock {
  id: string;
  appliesTo: string[]; // design system ids this block is relevant to
  text: string;
  placement: "productPage" | "footer" | "both";
}

export const COMPLIANCE_LIBRARY: ComplianceBlock[] = [
  {
    id: "caffeine_disclosure",
    appliesTo: ["energy", "tea_coffee"],
    text: "Contains caffeine. Not recommended for children, pregnant or breastfeeding women, or individuals sensitive to caffeine.",
    placement: "productPage",
  },
  {
    id: "supplement_statement",
    appliesTo: ["protein_nutrition"],
    text: "These statements have not been evaluated by [regulatory body]. This product is not intended to diagnose, treat, cure, or prevent any disease.",
    placement: "productPage",
  },
  {
    id: "probiotic_disclaimer",
    appliesTo: ["kombucha_probiotic"],
    text: "Contains live cultures. Consult a healthcare professional before use if immunocompromised.",
    placement: "productPage",
  },
  {
    id: "allergen_line",
    appliesTo: [
      "energy",
      "hydration",
      "tea_coffee",
      "juice_functional",
      "youth_party",
      "premium_mixers",
      "protein_nutrition",
      "kombucha_probiotic",
      "sparkling_soda",
      "coconut_natural",
      "nonalc_spirits",
    ],
    text: "Allergen information: see ingredient list on packaging. Manufactured in a facility that also processes [allergen placeholders].",
    placement: "productPage",
  },
  {
    id: "fssai_license_footer",
    appliesTo: [
      "energy",
      "hydration",
      "tea_coffee",
      "juice_functional",
      "youth_party",
      "premium_mixers",
      "protein_nutrition",
      "kombucha_probiotic",
      "sparkling_soda",
      "coconut_natural",
      "nonalc_spirits",
    ],
    text: "FSSAI Lic. No. [FSSAI_LICENSE_NUMBER]",
    placement: "footer",
  },
];

export function getComplianceBlocks(designSystemId: string, placement?: "productPage" | "footer") {
  return COMPLIANCE_LIBRARY.filter(
    (b) =>
      b.appliesTo.includes(designSystemId) &&
      (!placement || b.placement === placement || b.placement === "both")
  );
}

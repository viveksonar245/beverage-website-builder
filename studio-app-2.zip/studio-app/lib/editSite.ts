import Anthropic from "@anthropic-ai/sdk";
import { GeneratedSite } from "./generateSite";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Only these keys are ever eligible for LLM-driven edits. compliance,
// system, and logoSvg are structural/regulatory — never patched by a
// free-text instruction, matching the "retrieved, not generated" rule
// from the architecture (see lib/compliance.ts).
const EDITABLE_KEYS = ["hero", "features", "testimonial", "cta"] as const;
type EditableKey = (typeof EDITABLE_KEYS)[number];

export interface EditResult {
  patch: Partial<Pick<GeneratedSite, EditableKey>>;
  touchedKeys: EditableKey[];
}

/**
 * Turns a plain-language instruction ("make the hero more premium",
 * "shorten the about section") into a patch on just the block(s) it
 * applies to — never a full-page rewrite. This keeps edits fast,
 * keeps everything the user didn't ask to change untouched, and keeps
 * compliance text completely out of reach of free-text edits.
 */
export async function editSite(site: GeneratedSite, instruction: string): Promise<EditResult> {
  const editableContent: Record<string, unknown> = {};
  for (const key of EDITABLE_KEYS) editableContent[key] = site[key];

  const prompt = `You are editing marketing copy for a beverage brand's website.

Current content (JSON):
${JSON.stringify(editableContent, null, 2)}

Edit instruction: "${instruction}"

Apply ONLY the change requested. Do not rewrite sections the instruction
doesn't mention. Do not touch nutrition facts, legal disclaimers, or
license numbers — none of those exist in the content above, and none
should be added.

Respond with ONLY a JSON object containing the top-level keys you
actually changed (a subset of "hero", "features", "testimonial", "cta"),
each with its FULL updated value (not a partial diff within the key).
If a key is unchanged, omit it entirely. No markdown fences, no preamble.

Example shape if only the hero changed:
{ "hero": { "headline": "...", "subcopy": "...", "primaryCta": "...", "secondaryCta": "..." } }`;

  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1200,
    messages: [{ role: "user", content: prompt }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("No text content returned from edit");
  }

  const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(cleaned) as Record<string, unknown>;

  // Defensive filter: even if the model returns an unexpected key
  // (e.g. tries to add "compliance"), only EDITABLE_KEYS ever apply.
  const patch: Partial<Pick<GeneratedSite, EditableKey>> = {};
  const touchedKeys: EditableKey[] = [];
  for (const key of EDITABLE_KEYS) {
    if (key in parsed) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (patch as any)[key] = parsed[key];
      touchedKeys.push(key);
    }
  }

  return { patch, touchedKeys };
}

import { PrismaAdapter } from "@auth/prisma-adapter";
import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import { prisma } from "./db";

/**
 * Real Google OAuth. Set GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET and
 * NEXTAUTH_SECRET / NEXTAUTH_URL in .env (see .env.example). This
 * replaces the "demo-user-id" stub that was previously threaded
 * through the onboarding flow — every route that touched userId
 * now reads it from the session instead of trusting the client.
 */
export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID as string,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
    }),
  ],
  session: { strategy: "database" },
  callbacks: {
    async session({ session, user }) {
      if (session.user) {
        (session.user as { id: string }).id = user.id;
      }
      return session;
    },
  },
};

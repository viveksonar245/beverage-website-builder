import { prisma } from "./db";
import { PLANS, FREE_TRIAL_SITE_LIMIT } from "./plans";

export interface SiteLimitCheck {
  allowed: boolean;
  reason?: string;
  siteCount: number;
  limit: number;
}

/**
 * A user's "active" subscription is whichever Subscription row has
 * status "active" and the latest createdAt — someone who upgraded or
 * re-subscribed may have several historical rows.
 */
export async function checkSiteLimit(userId: string): Promise<SiteLimitCheck> {
  const [siteCount, activeSubscription] = await Promise.all([
    prisma.site.count({ where: { userId } }),
    prisma.subscription.findFirst({
      where: { userId, status: "active" },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  const limit = activeSubscription ? PLANS[activeSubscription.planId as keyof typeof PLANS].siteLimit : FREE_TRIAL_SITE_LIMIT;

  if (siteCount < limit) {
    return { allowed: true, siteCount, limit };
  }

  return {
    allowed: false,
    reason: activeSubscription
      ? `Your ${activeSubscription.planId} plan allows ${limit} site${limit === 1 ? "" : "s"}. Upgrade to add more.`
      : `You've used your free site. Subscribe to a plan to build more.`,
    siteCount,
    limit,
  };
}

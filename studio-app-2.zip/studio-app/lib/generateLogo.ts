import { BlendedSystem } from "./blend";

export interface LogoResult {
  svg: string;
  hasMark: boolean;
}

/**
 * Generates a logo as an inline SVG string, composed from the SAME
 * design system tokens used for the site — never a freeform image
 * model. This is the "select and populate" discipline from the
 * design brief: the mark comes from the resolved system's markPath
 * (see lib/designSystems.ts), the type comes from its typography
 * tokens, and the color comes from its accent — nothing here is
 * invented per-brand, only composed.
 *
 * Two layouts:
 *  - mark + wordmark, when the system defines a markPath (most
 *    categories)
 *  - type-only wordmark with a thin accent rule, when markPath is
 *    null (Premium & Craft Mixers, by design)
 *
 * NOTE: real browser/system fonts won't render inside a raw <svg>
 * <text> element the way they do in HTML — this is fine for an
 * on-screen preview (rendered inside an HTML page via
 * dangerouslySetInnerHTML) but a production export-to-PNG/favicon
 * pipeline needs either an HTML/canvas render step or self-hosted
 * font embedding. Flagged here rather than silently shipped broken.
 */
export function generateLogo(brandName: string, system: BlendedSystem): LogoResult {
  const name = brandName.trim().toUpperCase() || "BRAND";
  const { accent, ink } = system.colors;
  const fontFamily = system.typography.display;
  const fontWeight = system.typography.displayWeight;
  const letterSpacing = system.typography.letterSpacing;

  if (!system.markPath) {
    // Type-only: wordmark + a thin accent rule beneath it.
    const width = 60 + name.length * 15;
    const svg = `<svg width="${width}" height="56" viewBox="0 0 ${width} 56" xmlns="http://www.w3.org/2000/svg">
  <text x="0" y="30" font-family="${fontFamily}, sans-serif" font-weight="${fontWeight}" font-size="24" letter-spacing="${letterSpacing}" fill="${ink}">${name}</text>
  <rect x="0" y="42" width="${width - 20}" height="2" fill="${accent}" />
</svg>`;
    return { svg, hasMark: false };
  }

  // Mark + wordmark: a rounded badge with the category's geometric
  // icon, followed by the wordmark in the system's type.
  const width = 108 + name.length * 15;
  const svg = `<svg width="${width}" height="56" viewBox="0 0 ${width} 56" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="4" width="48" height="48" rx="${Math.min(system.spacing.radius, 24)}" fill="${system.colors.accentSoft}" />
  <path d="${system.markPath}" transform="translate(12, 16) scale(1)" fill="none" stroke="${accent}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
  <text x="60" y="34" font-family="${fontFamily}, sans-serif" font-weight="${fontWeight}" font-size="22" letter-spacing="${letterSpacing}" fill="${ink}">${name}</text>
</svg>`;
  return { svg, hasMark: true };
}

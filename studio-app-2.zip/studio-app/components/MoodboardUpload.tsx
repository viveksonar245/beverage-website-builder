"use client";

import { useState } from "react";

/**
 * Extracts a single dominant color from an image using a canvas
 * pixel sample. This is deliberately simple (average of a downsampled
 * grid, not real clustering) — good enough to nudge a design system's
 * accent (see lib/moodboard.ts), not a replacement for real palette
 * extraction if that's ever needed elsewhere.
 *
 * Runs entirely in the browser: no Pinterest/Behance API integration
 * (their public APIs don't reliably support this, per the product
 * notes), just direct image uploads.
 */
function extractDominantColor(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const size = 32; // downsample — we only need an average, not detail
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d");
      if (!ctx) return reject(new Error("Canvas unavailable"));
      ctx.drawImage(img, 0, 0, size, size);
      const { data } = ctx.getImageData(0, 0, size, size);
      let r = 0,
        g = 0,
        b = 0,
        count = 0;
      for (let i = 0; i < data.length; i += 4) {
        r += data[i];
        g += data[i + 1];
        b += data[i + 2];
        count++;
      }
      const toHex = (v: number) => Math.round(v / count).toString(16).padStart(2, "0");
      resolve(`#${toHex(r)}${toHex(g)}${toHex(b)}`);
      URL.revokeObjectURL(img.src);
    };
    img.onerror = () => reject(new Error("Failed to load image"));
    img.src = URL.createObjectURL(file);
  });
}

export default function MoodboardUpload({ onColorExtracted }: { onColorExtracted: (hex: string | null) => void }) {
  const [expanded, setExpanded] = useState(false);
  const [swatches, setSwatches] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setLoading(true);
    try {
      const colors = await Promise.all(Array.from(files).slice(0, 5).map(extractDominantColor));
      setSwatches(colors);
      // Average the per-image dominant colors into one signal.
      const avg = colors
        .map((hex) => [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)])
        .reduce((acc, c) => [acc[0] + c[0], acc[1] + c[1], acc[2] + c[2]], [0, 0, 0])
        .map((v) => Math.round(v / colors.length));
      const toHex = (v: number) => v.toString(16).padStart(2, "0");
      onColorExtracted(`#${toHex(avg[0])}${toHex(avg[1])}${toHex(avg[2])}`);
    } finally {
      setLoading(false);
    }
  }

  if (!expanded) {
    return (
      <button
        type="button"
        onClick={() => setExpanded(true)}
        className="self-start text-xs font-semibold text-indigo-600"
      >
        + Add a moodboard (optional)
      </button>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <span className="text-xs font-semibold text-zinc-700">
        Moodboard — upload 3–5 reference images that feel like your brand
      </span>
      <input
        type="file"
        accept="image/*"
        multiple
        onChange={(e) => handleFiles(e.target.files)}
        className="text-xs"
      />
      {loading && <span className="text-xs text-zinc-400">Reading colors…</span>}
      {swatches.length > 0 && (
        <div className="flex gap-2">
          {swatches.map((c, i) => (
            <span key={i} className="h-6 w-6 rounded-full border border-zinc-200" style={{ background: c }} />
          ))}
        </div>
      )}
    </div>
  );
}

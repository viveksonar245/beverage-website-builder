import { GeneratedSite } from "@/lib/generateSite";

/**
 * Renders a generated site using its blended design system's tokens.
 * This is intentionally plain inline styles (not Tailwind classes)
 * because the tokens are dynamic per-brand data, not fixed utility
 * classes — the same pattern the design-canvas mockup used.
 */
export default function SitePreview({ site }: { site: GeneratedSite }) {
  const { system } = site;
  const density = { airy: 96, balanced: 64, tight: 40 }[system.spacing.density];

  return (
    <div
      style={{
        background: system.colors.background,
        color: system.colors.ink,
        fontFamily: `'${system.typography.body}', sans-serif`,
      }}
    >
      <nav
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: `24px 64px`,
        }}
      >
        {site.logoSvg ? (
          <div dangerouslySetInnerHTML={{ __html: site.logoSvg }} />
        ) : (
          <div
            style={{
              fontFamily: `'${system.typography.display}', sans-serif`,
              fontWeight: system.typography.displayWeight,
              letterSpacing: system.typography.letterSpacing,
              fontSize: 22,
              color: system.colors.accent,
            }}
          >
            {site.brandName.toUpperCase()}
          </div>
        )}
        <a
          href="#"
          style={{
            padding: "12px 24px",
            borderRadius: 999,
            background: system.colors.accent,
            color: "#fff",
            fontSize: 14,
            fontWeight: 600,
          }}
        >
          {site.hero.primaryCta}
        </a>
      </nav>

      <section
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
          gap: 20,
          padding: `${density}px 64px`,
        }}
      >
        <h1
          style={{
            fontFamily: `'${system.typography.display}', sans-serif`,
            fontWeight: system.typography.displayWeight,
            fontSize: 48,
            maxWidth: 720,
            margin: 0,
          }}
        >
          {site.hero.headline}
        </h1>
        <p style={{ maxWidth: 520, color: system.colors.muted, fontSize: 17 }}>{site.hero.subcopy}</p>
        <div style={{ display: "flex", gap: 14 }}>
          <a
            href="#"
            style={{
              padding: "14px 28px",
              borderRadius: system.spacing.radius,
              background: system.colors.accent,
              color: "#fff",
              fontWeight: 600,
            }}
          >
            {site.hero.primaryCta}
          </a>
          <a
            href="#"
            style={{
              padding: "14px 28px",
              borderRadius: system.spacing.radius,
              border: `1.5px solid ${system.colors.muted}`,
              color: system.colors.ink,
              fontWeight: 600,
            }}
          >
            {site.hero.secondaryCta}
          </a>
        </div>
      </section>

      <section
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
          gap: 32,
          padding: `${density * 0.6}px 64px`,
        }}
      >
        {site.features.map((f, i) => (
          <div
            key={i}
            style={{
              background: system.colors.surface,
              borderRadius: system.spacing.radius,
              padding: 28,
            }}
          >
            <div
              style={{
                fontFamily: `'${system.typography.display}', sans-serif`,
                fontWeight: 600,
                fontSize: 17,
                marginBottom: 10,
              }}
            >
              {f.title}
            </div>
            <div style={{ color: system.colors.muted, fontSize: 14, lineHeight: 1.55 }}>{f.body}</div>
          </div>
        ))}
      </section>

      <section
        style={{
          background: system.colors.accentSoft,
          textAlign: "center",
          padding: `${density * 0.7}px 64px`,
        }}
      >
        <p
          style={{
            fontFamily: `'${system.typography.display}', sans-serif`,
            fontSize: 22,
            maxWidth: 620,
            margin: "0 auto 12px",
          }}
        >
          &quot;{site.testimonial.quote}&quot;
        </p>
        <span style={{ color: system.colors.accent, fontWeight: 600, fontSize: 14 }}>
          {site.testimonial.attribution}
        </span>
      </section>

      {site.signatureSection && (
        <section style={{ padding: `${density * 0.5}px 64px`, boxSizing: "border-box" }}>
          <h2
            style={{
              fontFamily: `'${system.typography.display}', sans-serif`,
              fontWeight: system.typography.displayWeight,
              fontSize: 26,
              marginBottom: 24,
              textAlign: "center",
            }}
          >
            {site.signatureSection.title}
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 24 }}>
            {site.signatureSection.items.map((item, i) => (
              <div key={i} style={{ background: system.colors.surface, borderRadius: system.spacing.radius, padding: 22 }}>
                <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 6 }}>{item.label}</div>
                <div style={{ fontSize: 13.5, color: system.colors.muted, lineHeight: 1.5 }}>{item.body}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Product-page compliance blocks — rendered verbatim, never touched by the LLM's output */}
      {site.compliance.productPage.length > 0 && (
        <section style={{ padding: "24px 64px", fontSize: 12.5, color: system.colors.muted }}>
          {site.compliance.productPage.map((line, i) => (
            <p key={i} style={{ margin: "4px 0" }}>
              {line}
            </p>
          ))}
        </section>
      )}

      <footer
        style={{
          display: "flex",
          justifyContent: "space-between",
          padding: "28px 64px",
          borderTop: `1px solid ${system.colors.surface}`,
          fontSize: 13,
          color: system.colors.muted,
        }}
      >
        <span>© {site.brandName}. All rights reserved.</span>
        {site.compliance.footer.map((line, i) => (
          <span key={i}>{line}</span>
        ))}
      </footer>
    </div>
  );
}

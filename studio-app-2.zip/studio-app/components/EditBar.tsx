"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function EditBar({ siteId, hasHistory }: { siteId: string; hasHistory: boolean }) {
  const router = useRouter();
  const [instruction, setInstruction] = useState("");
  const [loading, setLoading] = useState(false);
  const [lastResult, setLastResult] = useState<string | null>(null);
  const [canUndo, setCanUndo] = useState(hasHistory);

  async function submitEdit() {
    if (!instruction.trim()) return;
    setLoading(true);
    setLastResult(null);
    try {
      const res = await fetch("/api/edit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ siteId, instruction }),
      });
      const data = await res.json();
      if (data.touchedKeys?.length > 0) {
        setLastResult(`Updated: ${data.touchedKeys.join(", ")}`);
        setCanUndo(true);
        setInstruction("");
        router.refresh(); // re-fetch the server component with the new content
      } else if (data.error) {
        setLastResult(data.error);
      } else {
        setLastResult("Nothing matched that instruction — try being more specific.");
      }
    } finally {
      setLoading(false);
    }
  }

  async function undo() {
    setLoading(true);
    try {
      await fetch("/api/edit/undo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ siteId }),
      });
      setLastResult("Reverted to previous version.");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex items-center gap-3 bg-zinc-800 px-7 py-3">
      <input
        value={instruction}
        onChange={(e) => setInstruction(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && submitEdit()}
        placeholder='Tell it what to change — e.g. "make the hero more premium"'
        className="flex-grow rounded-lg border-none bg-zinc-700 px-3.5 py-2 text-sm text-white placeholder:text-zinc-400"
      />
      <button
        onClick={submitEdit}
        disabled={loading || !instruction.trim()}
        className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-40"
      >
        {loading ? "Working…" : "Apply"}
      </button>
      {canUndo && (
        <button
          onClick={undo}
          disabled={loading}
          className="rounded-lg border border-zinc-600 px-3 py-2 text-xs font-semibold text-zinc-200 disabled:opacity-40"
        >
          Undo
        </button>
      )}
      {lastResult && <span className="text-xs text-zinc-400">{lastResult}</span>}
    </div>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { DESIGN_SYSTEMS } from "@/lib/designSystems";
import { conflictNote } from "@/lib/blend";

const CATEGORY_LIST = Object.values(DESIGN_SYSTEMS);

export default function CategoryPicker() {
  const router = useRouter();
  // Order matters: index 0 = primary, index 1 = secondary, rest = tone-only.
  // See lib/blend.ts for what each position controls.
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [customMode, setCustomMode] = useState(false);
  const [customText, setCustomText] = useState("");

  function toggle(id: string) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function handleContinue() {
    const params = new URLSearchParams();
    params.set("categories", selectedIds.join(","));
    if (customMode && customText.trim()) {
      params.set("custom", customText.trim());
    }
    router.push(`/onboarding?${params.toString()}`);
  }

  const note = conflictNote(selectedIds);

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-7 p-12">
      <div className="flex flex-col gap-1.5">
        <div className="font-outfit text-xl font-bold tracking-wide">Studio</div>
        <h1 className="mt-1 font-outfit text-2xl font-bold">What are you building?</h1>
        <p className="text-sm text-zinc-500">
          Pick one, or a few — we&apos;ll blend design cues from each. Don&apos;t see your category?
          Tell us and we&apos;ll build a new one.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {CATEGORY_LIST.map((cat) => {
          const isSelected = selectedIds.includes(cat.id);
          return (
            <button
              key={cat.id}
              onClick={() => toggle(cat.id)}
              className={`relative flex items-center gap-3 rounded-2xl border p-4 text-left transition-colors ${
                isSelected ? "border-indigo-600 bg-indigo-50" : "border-zinc-200 bg-white"
              }`}
            >
              <span className="text-sm font-semibold">{cat.label}</span>
              {isSelected && (
                <span className="absolute right-2.5 top-2.5 text-xs font-bold text-indigo-600">
                  {selectedIds.indexOf(cat.id) === 0 ? "Primary" : selectedIds.indexOf(cat.id) === 1 ? "Secondary" : "✓"}
                </span>
              )}
            </button>
          );
        })}

        <button
          onClick={() => setCustomMode((v) => !v)}
          className={`flex items-center gap-3 rounded-2xl border border-dashed p-4 text-left ${
            customMode ? "border-indigo-600 bg-indigo-50" : "border-zinc-300 bg-white"
          }`}
        >
          <span className="text-sm font-semibold">Something else</span>
        </button>
      </div>

      {note && <p className="rounded-lg bg-amber-50 p-3 text-xs text-amber-800">{note}</p>}

      {customMode && (
        <div className="flex max-w-md flex-col gap-2">
          <label htmlFor="customCategory" className="text-xs font-semibold text-zinc-700">
            Describe your category
          </label>
          <input
            id="customCategory"
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            placeholder="e.g. adaptogenic mushroom coffee"
            className="rounded-lg border border-zinc-300 px-3.5 py-3 text-sm"
          />
        </div>
      )}

      <div className="flex justify-end">
        <button
          onClick={handleContinue}
          disabled={selectedIds.length === 0 && !(customMode && customText.trim())}
          className="rounded-xl bg-indigo-600 px-7 py-3.5 text-sm font-semibold text-white disabled:opacity-40"
        >
          Continue →
        </button>
      </div>
    </div>
  );
}

import { NextRequest, NextResponse } from "next/server";

/**
 * Multi-tenant domain routing.
 *
 * Requests to the platform's own domain (yourapp.com, a Vercel
 * preview URL, or localhost in dev) use the app's normal routes —
 * "/" is the category picker, "/dashboard" is the dashboard, etc.
 *
 * Any OTHER host is a customer's connected custom domain (popstar.com,
 * once they've completed /domain) — those get rewritten to
 * /_sites/[...] instead, so visiting popstar.com serves THAT brand's
 * generated site, not your platform's own homepage.
 *
 * Deliberately NOT doing the domain -> Site database lookup here:
 * middleware runs on the Edge runtime, where Prisma's Node.js client
 * doesn't work reliably. The lookup happens in
 * app/_sites/[[...slug]]/page.tsx, a normal Node.js server component,
 * using the Host header this middleware preserves. Middleware's only
 * job is deciding WHICH requests to send there.
 */

function getPlatformHost(): string {
  try {
    return new URL(process.env.NEXTAUTH_URL ?? "http://localhost:3000").host;
  } catch {
    return "localhost:3000";
  }
}

export function middleware(req: NextRequest) {
  const host = req.headers.get("host") ?? "";
  const platformHost = getPlatformHost();

  const isPlatformTraffic =
    host === platformHost || host.endsWith(".vercel.app") || host.startsWith("localhost");

  if (isPlatformTraffic) {
    return NextResponse.next();
  }

  const url = req.nextUrl.clone();
  url.pathname = `/_sites${req.nextUrl.pathname}`;
  return NextResponse.rewrite(url);
}

export const config = {
  // Skip static assets, images, and API routes — API routes are
  // session-gated anyway, and a customer domain has no legitimate
  // reason to hit your platform's API surface directly.
  matcher: ["/((?!_next|api|favicon.ico).*)"],
};
